import React from 'react'

const ShowProfile = (props)=> {

    return (
        <section>
            <div className="section_content">
                <h2 className="section_title">{props.employee.name}</h2>
                <p>{props.employee.portfolio_link}</p>
                <button className="btn btn-primary" onClick={() => props.handleEditShow()}>Edit</button>
            </div>
        </section>
    )
}

export default ShowProfile;