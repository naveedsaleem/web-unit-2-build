import React, {useState, useEffect} from 'react'
import ShowProfile from './ShowProfile'
import AddProfileForm from './AddProfileForm'
import EditProfileForm from './EditProfileForm'
import Skill from '../Skill/Skill'
import Resume from '../Resume/Resume'
import Education from '../Education/Education'
import { axiosWithAuth } from '../../utils.js'
import "bootstrap/dist/css/bootstrap.min.css"
import '../JobSeeker.css'

const Profile = () => {

    const [employee, setEmployee] = useState([]);

    useEffect(() => {

        const token = localStorage.getItem('token')
        const user = JSON.parse(atob(token.split('.')[1])) 
        
        axiosWithAuth()
            .get(`https://droom1.herokuapp.com/api/employee/${user.id}`)
            // just put in a url you want data from
            .then(res => {
                setEmployee(res.data)
                console.log("Success:", res);
            })
            // do stuff with whatever gets returned
            .catch(err => {
            console.log("Error:", err.response);           
        });

    }, []);


    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const [editShow, setEditShow] = useState(false);
    const handleEditClose = () => setEditShow(false);
    const handleEditShow = () => setEditShow(true);

    const addProfile = (profile) => {
        setEmployee(profile);
    }

    const updateProfile = (updateProfile) => {
        setEmployee(updateProfile);
    }

    return (
        <div>
            {employee.length === 0 ? (
                <div className="profile-content">
                 <section>
                <div className="section_content">
                    <div className="section_top_content">
                        <div className="section_action">
                            <div><button className="btn btn-success btn-lg" onClick={handleShow}>Add Profile</button></div>
                        </div>
                    </div>
                    <AddProfileForm show={show} handleClose={handleClose} addProfile={addProfile} />
                </div>
                </section>
                </div>
               ) : (
                <div className="profile-content">
                    <ShowProfile employee={employee} handleEditShow={handleEditShow} />
                    <EditProfileForm editShow={editShow} handleEditClose={handleEditClose} employee={employee} updateProfile={updateProfile} />
                    <Skill employee={employee} />
                    <Resume employee={employee} />
                    <Education employee={employee} />
                </div>
             )}
        </div>
    )
}

export default Profile;